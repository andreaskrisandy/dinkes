<?php
	header("location: dashboard.php?page=main");
?>